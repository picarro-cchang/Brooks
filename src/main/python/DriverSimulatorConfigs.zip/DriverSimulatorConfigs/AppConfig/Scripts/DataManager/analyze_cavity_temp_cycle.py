for k in _DATA_.keys():
    _REPORT_[k] = _DATA_[k]
